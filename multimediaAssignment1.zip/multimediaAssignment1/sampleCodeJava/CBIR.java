/* Project 1
*/

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.net.MalformedURLException;
import java.util.*;
import java.io.*;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.*;

public class CBIR extends JFrame {
    private final JLabel photographLabel = new JLabel();  //container to hold a large
    JLabel pageLabel = new JLabel();
    private final JButton [] button; //creates an array of JButtons
    private final int [] buttonOrder = new int [101]; //creates an array to keep up with the image order
    private final JPanel imagesPanel;
    int picNo = 0;
    int imageCount = 1; //keeps up with the number of images displayed since the first page.
    int intensityImageCount = 1;
    int colorCodeImageCount = 1;
    FEATURE feature = FEATURE.NONE;
    private final int[] intensityOrder = new int[101];
    private final int[] colorCodeOrder = new int[101];

    public static void main(String args[]) {

        SwingUtilities.invokeLater(() -> {
            CBIR app = null;
            try {
                app = new CBIR();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            app.setVisible(true);
        });
    }

    public CBIR() throws IOException {
        //The following lines set up the interface including the layout of the buttons and JPanels.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle("Content Based Image Retrieval System");

        GridLayout overallLayout = new GridLayout(1, 2, 5, 5);
        setLayout(overallLayout);

        imagesPanel = new JPanel();
        // this layout shows the retrieved images in a page
        GridLayout gridLayout1 = new GridLayout(4, 5, 5, 5);
        imagesPanel.setLayout(gridLayout1);

        JPanel panelTop = new JPanel();
        panelTop.setLayout(new BorderLayout());

        photographLabel.setVerticalTextPosition(JLabel.BOTTOM);
        photographLabel.setHorizontalTextPosition(JLabel.CENTER);
        photographLabel.setHorizontalAlignment(JLabel.CENTER);
        photographLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
//        JPanel newPanel1 = new JPanel(new FlowLayout());



        JButton previousPage = new JButton("<<");
        JButton nextPage = new JButton(">>");
        JRadioButton  intensity, colorCode, none;

        intensity = new JRadioButton("Intensity");
        colorCode = new JRadioButton("Color Code");
        none = new JRadioButton("Inorder", true);
        none.setSelected(true);

        //buttons are grouped together so that it will be easy for user to remember which option they selected.
        ButtonGroup bg = new ButtonGroup();
        JLabel featureLabel = new JLabel();
        featureLabel.setVerticalTextPosition(JLabel.BOTTOM);
        featureLabel.setHorizontalTextPosition(JLabel.CENTER);
        featureLabel.setHorizontalAlignment(JLabel.CENTER);
        featureLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        featureLabel.setText("Select Feature");

        bg.add(intensity);bg.add(colorCode);bg.add(none);

        JPanel featurePanel = new JPanel();
        featurePanel.setLayout(new GridLayout(1,3));
        featurePanel.add(intensity);
        featurePanel.add(colorCode);
        featurePanel.add(none);
        Font font = new Font("Courier", Font.ITALIC, 20);
        featureLabel.setFont(font);
        none.setFont(font);
        intensity.setFont(font);
        colorCode.setFont(font);


//        panelTop.add(photographLabel, BorderLayout.CENTER);
//        panelTop.add(featurePanel, BorderLayout.NORTH);




        panelTop.add(photographLabel, BorderLayout.CENTER);

        JPanel panelX = new JPanel();
        panelX.setLayout(new BorderLayout());
        panelX.add(featureLabel, BorderLayout.NORTH);
        panelX.add(featurePanel, BorderLayout.CENTER);
        panelTop.add(panelX, BorderLayout.SOUTH);

        nextPage.addActionListener(new nextPageHandler());
        previousPage.addActionListener(new previousPageHandler());
        none.addActionListener(new noneHandler());
        intensity.addActionListener(new intensityHandler());
        colorCode.addActionListener(new colorCodeHandler());

        setSize(1100, 750);
        // this centers the frame on the screen
        // setLocationRelativeTo(null);

        button = new JButton[101];
        /*This for loop goes through the images in the database and stores them as icons and adds
         * the images to JButtons and then to the JButton array
        */
        for (int i = 1; i < 101; i++) {
                ImageIcon icon;
                // Here we basically need to get URL to the selected image, so i gave my imagespath and converted that to URL
                icon = new ImageIcon(new File(imageBasePath + i + ".jpg").toURI().toURL());

                 if(icon != null){
                    button[i] = new JButton(icon);
                    //imagesPanel.add(button[i]);
                    button[i].addActionListener(new IconButtonHandler(i, icon));
                    buttonOrder[i] = i;
                }
        }
        add(panelTop);

        JPanel newPanel = new JPanel();
        newPanel.setLayout(new BorderLayout());
        newPanel.add(imagesPanel, BorderLayout.CENTER);


        pageLabel.setVerticalTextPosition(JLabel.BOTTOM);
        pageLabel.setHorizontalTextPosition(JLabel.CENTER);
        pageLabel.setHorizontalAlignment(JLabel.CENTER);
        pageLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel buttonPanel = new JPanel();


        GroupLayout groupLayout = new GroupLayout(buttonPanel);
        groupLayout.setAutoCreateGaps(true);
        groupLayout.setAutoCreateContainerGaps(true);

        groupLayout.setHorizontalGroup(groupLayout.createSequentialGroup()
                .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(previousPage))
                .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.CENTER)
                        .addComponent(pageLabel))
                .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(nextPage)));
        groupLayout.setVerticalGroup(groupLayout.createSequentialGroup()
                .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.CENTER)
                        .addComponent(previousPage).addComponent(pageLabel).addComponent(nextPage)));

        buttonPanel.setLayout(new GridLayout(1,3));
        buttonPanel.add(previousPage);
        buttonPanel.add(pageLabel);
        buttonPanel.add(nextPage);
        newPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(newPanel);

        displayFirstPage();
        new ReadImage();
        setVisible(true);
    }

    /*This method displays the first twenty images in the panelBottom.  The for loop starts at number one and gets the image
     * number stored in the buttonOrder array and assigns the value to imageButNo.  The button associated with the image is
     * then added to imagesPanel.  The for loop continues this process until twenty images are displayed in the imagesPanel
    */
    private void displayFirstPage() {
        feature = FEATURE.NONE;
      int imageButNo = 0;
        imagesPanel.removeAll();
      for(int i = 1; i < 21; i++){
        imageButNo = buttonOrder[i];
        imagesPanel.add(button[imageButNo]);
      }
      imageCount = 21;
      changeLabel();
      imagesPanel.revalidate();
      imagesPanel.repaint();
    }

    /*This class implements an ActionListener for each iconButton.  When an icon button is clicked, the image on the
     * the button is added to the photographLabel and the picNo is set to the image number selected and being displayed.
    */
    private class IconButtonHandler implements ActionListener{
      int pNo = 0;
      ImageIcon iconUsed;

      IconButtonHandler(int i, ImageIcon j){
        pNo = i;
        iconUsed = j;  //sets the icon to the one used in the button
      }

      //if any button among intensity/colorcode is selected then the required action will be performed.
      public void actionPerformed( ActionEvent e){
        photographLabel.setIcon(iconUsed);
        photographLabel.setText(pNo + ".jpg");
        Font font = new Font("Courier", Font.ITALIC, 16);
        photographLabel.setFont(font);
            picNo = pNo;
            if (FEATURE.INTENSITY.equals(feature))
            {
                new intensityHandler().actionPerformed(e);
            } else if (FEATURE.COLORCODE.equals(feature))
            {
                new colorCodeHandler().actionPerformed(e);
            }
      }
    }

    /*This class implements an ActionListener for the nextPageButton.  The last image number to be displayed is set to the
     * current image count plus 20.  If the endImage number equals 101, then the next page button does not display any new
     * images because there are only 100 images to be displayed.  The first picture on the next page is the image located in
     * the buttonOrder array at the imageCount
    */
    private class nextPageHandler implements ActionListener{

      public void actionPerformed( ActionEvent e){
          int imageNumber;
          if (FEATURE.NONE.equals(feature))
          {
              imageNumber = imageCount;
          } else if (FEATURE.INTENSITY.equals(feature))
          {
              imageNumber = intensityImageCount;
          } else
          {
              imageNumber = colorCodeImageCount;
          }
          int endImage = imageNumber + 20;
          if(endImage <= 101){
            imagesPanel.removeAll();
            for (int i = imageNumber; i < endImage; i++) {
                if (FEATURE.NONE.equals(feature))
                {
                    imageNumber = buttonOrder[i];
                } else if (FEATURE.INTENSITY.equals(feature))
                {
                    imageNumber = intensityOrder[i];
                } else
                {
                    imageNumber = colorCodeOrder[i];
                }
                    imagesPanel.add(button[imageNumber]);

                if (FEATURE.NONE.equals(feature))
                {
                    imageCount++;
                } else if (FEATURE.INTENSITY.equals(feature))
                {
                    intensityImageCount++;
                } else
                {
                    colorCodeImageCount++;
                }
            }

            changeLabel();
            imagesPanel.revalidate();
            imagesPanel.repaint();
          }
      }
    }

    /*This class implements an ActionListener for the previousPageButton.  The last image number to be displayed is set to the
     * current image count minus 40.  If the endImage number is less than 1, then the previous page button does not display any new
     * images because the starting image is 1.  The first picture on the next page is the image located in
     * the buttonOrder array at the imageCount
    */
    private class previousPageHandler implements ActionListener{

      public void actionPerformed( ActionEvent e){
          int imageNumber;
          if (FEATURE.NONE.equals(feature))
          {
              imageNumber = imageCount;
          } else if (FEATURE.INTENSITY.equals(feature))
          {
              imageNumber = intensityImageCount;
          } else
          {
              imageNumber = colorCodeImageCount;
          }

          int startImage = imageNumber - 40;
          int endImage = imageNumber - 20;
          if(startImage >= 1){
            imagesPanel.removeAll();
            /*The for loop goes through the buttonOrder array starting with the startImage value
             * and retrieves the image at that place and then adds the button to the imagesPanel.
            */
            for (int i = startImage; i < endImage; i++) {
                    if (FEATURE.NONE.equals(feature))
                    {
                        imageNumber = buttonOrder[i];
                    } else if (FEATURE.INTENSITY.equals(feature))
                    {
                        imageNumber = intensityOrder[i];
                    } else
                    {
                        imageNumber = colorCodeOrder[i];
                    }
                    imagesPanel.add(button[imageNumber]);
                    if (FEATURE.NONE.equals(feature))
                    {
                        imageCount--;
                    } else if (FEATURE.INTENSITY.equals(feature))
                    {
                        intensityImageCount--;
                    } else
                    {
                        colorCodeImageCount--;
                    }
            }
            changeLabel();
            imagesPanel.revalidate();
            imagesPanel.repaint();
          }
      }
    }

    private class noneHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            displayFirstPage();
        }
    }

    /*This class implements an ActionListener when the user selects the intensityHandler button.  The image number that the
     * user would like to find similar images for is stored in the variable pic.  pic takes the image number associated with
     * the image selected and subtracts one to account for the fact that the intensityMatrix starts with zero and not one.
     * The size of the image is retrieved from the imageSize array.  The selected image's intensity bin values are
     * compared to all the other image's intensity bin values and a score is determined for how well the images compare.
     * The images are then arranged from most similar to the least.
     */
    private class intensityHandler implements ActionListener{

      public void actionPerformed( ActionEvent e) {
          feature = FEATURE.INTENSITY;

          float[] distance = new float[ReadImage.numberOfPhotos];
          Map <Float, List<Integer>> hashMap = new HashMap<>();
          int pic = (picNo - 1);

          // get manhannatten distance
          for (int photo = 0; photo < ReadImage.numberOfPhotos; photo++){
              distance[photo] = ReadImage.calculateIntensityManhattanDistance(pic, photo);
              if (hashMap.containsKey(distance[photo]))
              {
                  hashMap.get(distance[photo]).add(photo);
              }
              else
              {
                  hashMap.put(distance[photo], Arrays.asList(photo));
              }
          }

          List<Float> keySetList = new ArrayList<>(hashMap.keySet());
          Collections.sort(keySetList);
          intensityImageCount = 1;
          for (Float key : keySetList)
          {
              List<Integer> photos = hashMap.get(key);
              for (Integer photo: photos)
              {
                  intensityOrder[intensityImageCount] = photo + 1;
                  intensityImageCount += 1;
              }
          }
          intensityImageCount = 21;

          int imageButNo;
          imagesPanel.removeAll();
          for( int i = 1 ; i < 21 ; i++){
              imageButNo = intensityOrder[i];
              imagesPanel.add(button[imageButNo]);
          }

          changeLabel();
          imagesPanel.revalidate();
          imagesPanel.repaint();
      }
    }

    /*This class implements an ActionListener when the user selects the colorCode button.  The image number that the
     * user would like to find similar images for is stored in the variable pic.  pic takes the image number associated with
     * the image selected and subtracts one to account for the fact that the intensityMatrix starts with zero and not one.
     * The size of the image is retrieved from the imageSize array.  The selected image's intensity bin values are
     * compared to all the other image's intensity bin values and a score is determined for how well the images compare.
     * The images are then arranged from most similar to the least.
     */
    private class colorCodeHandler implements ActionListener{

      public void actionPerformed( ActionEvent e) {
          feature = FEATURE.COLORCODE;
          float[] distance = new float[ReadImage.numberOfPhotos];
          Map <Float, List<Integer>> hashMap = new HashMap<>();
          int pic = (picNo - 1);

          // get manhannatten distance
          for (int photo = 0; photo < ReadImage.numberOfPhotos; photo++){
              distance[photo] = ReadImage.calculateColorCodeManhattanDistance(pic, photo);
              if (hashMap.containsKey(distance[photo]))
              {
                  hashMap.get(distance[photo]).add(photo);
              }
              else{
                  List<Integer> photos = new ArrayList<>();
                  photos.add(photo);
                  hashMap.put(distance[photo], photos);
              }
          }
          List<Float> keySetList = new ArrayList<>(hashMap.keySet());
          Collections.sort(keySetList);
          colorCodeImageCount = 1;
          for (Float key : keySetList)
          {

              List<Integer> photos = hashMap.get(key);
              for (Integer photo: photos)
              {
                  colorCodeOrder[colorCodeImageCount] = photo + 1;
                  colorCodeImageCount += 1;

              }
          }

          colorCodeImageCount = 21;
          int imageButNo;
          imagesPanel.removeAll();
          for( int i = 1 ; i < 21 ; i++){
              imageButNo = colorCodeOrder[i];
              imagesPanel.add(button[imageButNo]);
          }

          changeLabel();
          imagesPanel.revalidate();
          imagesPanel.repaint();
      }
    }

    private int getCurrentPage()
    {
        int currentPage;
        if (FEATURE.NONE.equals(feature))
        {
            currentPage = imageCount/20;
        } else if (FEATURE.INTENSITY.equals(feature))
        {
            currentPage = intensityImageCount/20;
        } else
        {
            currentPage = colorCodeImageCount/20;
        }
        return currentPage;
    }

    enum FEATURE {
        NONE,
        INTENSITY,
        COLORCODE;
    }

    private void changeLabel()
    {
        pageLabel.setText("Page " + getCurrentPage() + "/5");
        Font font = new Font("Courier", Font.ITALIC, 16);
        pageLabel.setFont(font);
        pageLabel.repaint();

    }

    private static final String imageBasePath = "/Users/dim/Downloads/images/";
}
