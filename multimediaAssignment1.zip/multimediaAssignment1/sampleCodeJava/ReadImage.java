/*
 * Project 1
*/

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;

import static java.lang.System.getProperty;


public class ReadImage
{
  public static final int numberOfPhotos = 100;
  private static final int intensityBinCount = 25;
  private static final int colorCodeBinCount = 64;

  private static final String imageBasePath = "images/";
  private static final String outputBasePath = "output.txt";

  int imageCount = 1;
  int intensityBins [] = new int [intensityBinCount];
  static int[][] intensityMatrix = new int[numberOfPhotos][intensityBinCount];
  int colorCodeBins [] = new int [colorCodeBinCount];
  static int[][] colorCodeMatrix = new int[numberOfPhotos][colorCodeBinCount];
  static int[] dimensions = new int [numberOfPhotos];

  /*Each image is retrieved from the image database. The height and width are found for the image and the getIntensityBin and
   * getcalculateColorCodeBin methods are called.
  */
  // Initializing all the values in the matrix to 0, so that in future the values can be easily updated.
  public ReadImage() throws IOException {
    for (int i = 0; i < numberOfPhotos; i++)
      for (int j = 0; j < intensityBinCount; j++)
        intensityMatrix[i][j] = 0;

    for (int i = 0; i < numberOfPhotos; i++)
      for (int j = 0; j < colorCodeBinCount; j++)
        colorCodeMatrix[i][j] = 0;

    // storing the dimesnions of every image
    for (int i = 0; i < numberOfPhotos; i++)
      dimensions[i] = 0;

    while (imageCount < (numberOfPhotos + 1)){
      BufferedImage img = null;
      try {
        img = ImageIO.read(new File(getProperty("user.dir") + File.separator + imageBasePath + imageCount + ".jpg"));
        int width = img.getWidth();
        int height = img.getHeight();
        dimensions[imageCount - 1] = height*width;
        for (int i = 0; i < height; i++)
        {
          for (int j = 0; j < width; j++)
          {
            Color color = new Color(img.getRGB(j, i));
            // get intensity bin
            int bin = getIntensityBin(color);
            intensityMatrix[imageCount - 1][bin] += 1;

            // get color code intensity
            int colorCodeBin = getcalculateColorCodeBin(color);
            colorCodeMatrix[imageCount - 1][colorCodeBin] += 1;
          }
        }
        imageCount++;
      } catch (IOException e) {
        throw e;
      }
    }
    writeIntensityandColorCode();
  }
  
  //intensity method
  public int getIntensityBin(Color color){
      int r = color.getRed();
      int g = color.getGreen();
      int b = color.getBlue();

      // Intensity formula
      double intensity = 0.299*r + 0.587*g + 0.114*b;
      int binNumber = (int) Math.floor(intensity) / 10;

      if (binNumber == intensityBinCount)
        binNumber = intensityBinCount - 1;

      return binNumber;
  }
  
  //color code method
  public int getcalculateColorCodeBin(Color color){
    int r = color.getRed();
    int g = color.getGreen();
    int b = color.getBlue();

    String significantBits = last2Bits(r) + last2Bits(g) + last2Bits(b);
    return Integer.parseInt(significantBits, 2);
  }

  // Method to obtain the first 2 digits from 6 digit binary code
  public String last2Bits(int value)
  {
    StringBuilder lastChars = new StringBuilder();
    int i = 0;
    while (i < 8)
    {
      int bit = value % 2;
      value = value / 2;
      lastChars.insert(0, bit);
      i++;
    }
    return lastChars.toString().substring(0, 2);
  }

  // this method calculates the manhattan distance between two images using intensityMatrix
  public static float calculateIntensityManhattanDistance(int image1, int image2)
  {
    float manhattan = 0;
    int i = 0 ;
    while (i < intensityBinCount)
    {

      float dist1 = (float)(intensityMatrix[image1][i])/dimensions[image1];
      float dist2 = (float)(intensityMatrix[image2][i])/dimensions[image2];
      manhattan += Math.abs( dist1 - dist2 );
      i ++;
    }
    return manhattan;
  }

  // This method is used to calculate the manhattan distance between two images using colorcode matrix
  public static Float calculateColorCodeManhattanDistance(int image1, int image2)
  {
    float manhattan = 0;
    int i= 0 ;
    while (i < colorCodeBinCount){
      float dist1 = (float)(colorCodeMatrix[image1][i])/dimensions[image1];
      float dist2 = (float)(colorCodeMatrix[image2][i])/dimensions[image2];
      manhattan += Math.abs( dist1 - dist2 );
      i ++;
    }
    return manhattan;
  }
  
  //This method writes the features of the intensity matrix and colorcode matrix to a file called output.txt
  public void writeIntensityandColorCode() throws IOException {
    BufferedWriter writer = new BufferedWriter(new FileWriter(getProperty("user.dir") + File.separator + outputBasePath));
    int i = 0; int j = 0;
    while (i < intensityBinCount || j < colorCodeBinCount)
    {
      writer.append(Arrays.toString(intensityMatrix[i]));
      writer.append("\n");
      writer.append(Arrays.toString(colorCodeMatrix[j]));
      writer.append("\n");
      writer.append("\n");
      i += 1;
      j += 1;
    }

    writer.flush();
    writer.close();
  }

 // Main class to read the images.
  public static void main(String[] args) throws IOException {
    new ReadImage();
  }
}
